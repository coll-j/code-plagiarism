package average;

public class Average {
	public float avg_float(float a, float b) {
		return a/b;
	}
}
