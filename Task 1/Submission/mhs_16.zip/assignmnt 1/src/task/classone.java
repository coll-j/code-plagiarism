package task;

import java.util.Scanner;

public class classone {
		@SuppressWarnings("resource")
		public static void main(String[] args) {
			
			// scanner 
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("what's your name?");
			String name = scan.next();
			
			System.out.println("what's your grade?");
			int grade = scan.nextInt();
				
			System.out.println("Hello " + name + ", your grade is " + grade);
			
		}
		
		
		// if else
		
		// Scanner scan = new Scanner(System.in);
		// System.out.println("enter a score:");
		
		//int n = scan.nextInt();
		//System.out.println(n);
		
		//if(n >= 70 && n <= 100) {
			
		//System.out.println("you passed");
			
		//} else {
			
		//System.out.println("try again");
		
	}





