package task2;

import java.util.Scanner;

public class classone {

	public static void main(String[] args) {
		
		byte a = 42;  
        char b = 'x';  
        short c = 1024; 
        float d = 5.67f; 
        double e = .1234; 
        int f = 50000; 
        

        double result = (d * a) + (f / b) - (e * c); 
        a = (byte)(a * 2);
        
        System.out.println(a);
        System.out.println("result = " + result); 
		
        
		//Do-While
		
//		   int x = 0;
//		   int q = 0;
//		   
//		   Scanner classone = new Scanner(System.in);
//	 
//		   System.out.println("Write negative number to stop");
//	  
//		   do {
//	     
//			   x += q;
//	     
//			   System.out.println("Input number : ");
//	      
//			   q = classone.nextInt();
//			   
//		    } while(q >= 0); 
//			   
//		    System.out.println("Sum = " + x);
			
		    
		    
				// SWITCH
			
//			Scanner classone = new Scanner(System.in);
//				char x;
//				int answer = 0;
//				int a=5;
//				int b=20;
//				
//			System.out.println("Write + or - or * or / or % : ");	
//			
//			x = classone.next().charAt(0);	
//
//			switch (x){ 
//				case '+':
//					answer = a + b;
//					break; 
//				case '-':
//					answer = a - b;
//					break;
//				case '*':
//					answer = a * b;
//				case '/':
//					answer = a / b;
//					break; 
//				case '%':
//					answer = a % b;
//					break;
//				default:
//					System.out.println("No answer");
//			}
//			System.out.println(answer);
		
		}
	}


