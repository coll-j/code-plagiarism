package Main;

import Tasks.Tugas;

	public class Main {
		
	public static void main(String[]args) {
		Tugas perintah =  new Tugas();
		
		perintah.Percabangan();
		perintah.Conversion();
		perintah.Loop();
		perintah.Switch(); }

}
