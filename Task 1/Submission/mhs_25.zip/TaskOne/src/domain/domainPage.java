package domain;

public class domainPage {
	public int num1;
	public int num2;
	
	public domainPage() {
		
	}
	
	
	public int getMultiply() {
		return num1 * num2;
	}
	
	public void setNum1(int num1) {
		this.num1 = num1;
	}
	
	public void setNum2(int num2) {
		this.num2 = num2;
	}
	
	
	
}
	