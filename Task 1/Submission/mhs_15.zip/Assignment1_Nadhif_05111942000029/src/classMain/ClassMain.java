package classMain;

import java.util.Scanner;
import ClassFunction.ClassFunction;

public class ClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
       
		ClassFunction order = new ClassFunction();
        
        order.Percabangan();
        order.Con();
        order.Looping();
        order.Switcher();  
	}

}
