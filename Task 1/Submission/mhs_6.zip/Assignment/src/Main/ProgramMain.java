package Main;

import Function.ProgramClass;

public class ProgramMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProgramClass s = new ProgramClass();
		
		s.scan();
		s.ifelse();
		s.cast();
		s.dowhile();
		s.switchcase();
		
	}

}
