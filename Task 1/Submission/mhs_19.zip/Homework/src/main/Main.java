package main;

import code.Homework;

public class Main {

	public static void main(String[] args) {
		Homework command = new Homework();
		
		command.ifelse();
		command.conversion();
		command.dowhile();
		command.switcher();
//		System.out.println("Program is end");
	}

}
