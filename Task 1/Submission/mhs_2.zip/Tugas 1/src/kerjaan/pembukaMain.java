package kerjaan; 

import tugas.bagiTugas;

public class pembukaMain
{
	public static void main(String[]args) {
		bagiTugas fungsi = new bagiTugas();
		
		fungsi.cabang();
		fungsi.conversion();
		fungsi.doWhile();
		fungsi.switcher();
	}
	
}
