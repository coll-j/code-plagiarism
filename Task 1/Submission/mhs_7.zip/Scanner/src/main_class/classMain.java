package main_class;
import java.util.Scanner;

import secondary.fungsiutama;


public class classMain {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        fungsiutama command = new fungsiutama();
        
        command.Scanner();
        command.Convert();
        command.Looping();
        command.Switching();  
	}
	
	

}
