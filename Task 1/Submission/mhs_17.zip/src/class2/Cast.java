package class2;

public class Cast {
    public static void main(String[] args){
        
        short data1 = 200;
        double double_data = data1; //short le double
        
        char data2 = 'B';
        long long_data = data2;//char ke long
        
        int  data3 = 345;
        float int_data = data3;// int ke float
        
        byte data4 = 127;
        long long_data2 = data4;//byte ke long
        
        float data5 = 565.3f;
        double double_data2 = data5;//float ke double
        
        System.out.println("Short ke Double: "+ double_data);
        System.out.println("Char ke Long: "+long_data);
        System.out.println("Int ke Float: "+int_data);
        System.out.println("Byte ke Long: "+long_data2);
        System.out.println("Float ke Double: "+double_data2);

        // do while

//       	 int i = 0;
//
//        	do {
//            	System.out.println("perulangan ke-" + i);
//            	i++;
//        	} while ( i <= 10);
//
//    	}
//	}
        
        // switch
//        	int num=2;
//        	switch(num+2)
//        	{
//           	case 1:
//   	  	System.out.println("Case1: Value is: "+num);
//   			case 2:
//   	  	System.out.println("Case2: Value is: "+num);
//   			case 3:
//   	  	System.out.println("Case3: Value is: "+num);
//           	default:
//   	  	System.out.println("Default: Value is: "+num);
//         	}
//      	}
//   	}
        
    }
}